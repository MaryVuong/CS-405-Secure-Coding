// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>  // Include for standard exceptions

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    // Override what() method to return a custom message
    const char* what() const throw() {
        return "Custom Exception: Something went wrong in Custom Application Logic";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    // Throw a standard exception
    throw std::runtime_error("Standard Exception: Failed in Even More Custom Application Logic");
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cout << "Exception caught: " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // Throw a custom exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // Throw an exception for divide by zero errors
    if (den == 0)
        throw std::invalid_argument("Divide by zero exception");
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try {
        // Try block to attempt division and potentially catch divide-by-zero errors
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e) {
        // Catch block specifically for std::exception and its derivatives thrown from divide()
        std::cout << "Exception caught while dividing: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    try {
        // The try block executes functions that might throw exceptions
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        // First catch block for custom exceptions thrown from custom application logic
        std::cout << "Custom Exception caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        // Second catch block for standard exceptions
        std::cout << "Standard Exception caught in main: " << e.what() << std::endl;
    }
    catch (...) {
        // Catch-all handler for any other uncaught exceptions
        std::cout << "An unhandled exception occurred." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu