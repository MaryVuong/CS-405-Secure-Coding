// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_order
    //  varaible, and its position in the declaration. It must always be directly before the variable used for input.

    // Account number must remain constant and untouched
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    // Inform user of character limit to prevent intentional overflow
    std::cout << "Enter a value (max 19 characters): ";

    // Use std::cin.getline to safely get user input with a limit of 19 characters
    // This prevents the user from inputting more characters than the buffer can hold
    std::cin.getline(user_input, 19);

    // Check if the failbit is set, which indicates that the input was too long
    if (std::cin.fail()) {
        std::cin.clear(); // Clear the fail state
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore leftover input
        std::cout << "Input truncated due to buffer overflow attempt." << std::endl;
    }

    // Output the results, showing that the buffer overflow has been mitigated
    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
